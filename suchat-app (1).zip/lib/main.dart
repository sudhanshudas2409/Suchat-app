
import 'package:flutter/material.dart';

void main() {
  runApp(SuchatApp());
}

class SuchatApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Suchat',
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
      ),
      home: Scaffold(
        appBar: AppBar(title: Text('Suchat')),
        body: Center(child: Text('Welcome to Suchat!')),
      ),
    );
  }
}
